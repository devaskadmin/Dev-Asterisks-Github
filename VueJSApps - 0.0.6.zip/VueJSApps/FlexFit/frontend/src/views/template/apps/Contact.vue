<script setup>

</script>

<template>
  <div class="row g-4">
    <div class="col-lg-6">
      <div class="panel">
        <div class="panel-header">
          <h5>Contact Form One</h5>
        </div>
        <div class="panel-body">
          <div class="row g-3">
            <div class="col-sm-6">
              <input type="text" class="form-control form-control-sm" placeholder="Your Name*">
            </div>
            <div class="col-sm-6">
              <input type="email" class="form-control form-control-sm" placeholder="Your Email*">
            </div>
            <div class="col-sm-6">
              <input type="tel" class="form-control form-control-sm" placeholder="Your Phone*">
            </div>
            <div class="col-sm-6">
              <input type="text" class="form-control form-control-sm" placeholder="Your Website*">
            </div>
            <div class="col-12">
              <input type="text" class="form-control form-control-sm" placeholder="Subject*">
            </div>
            <div class="col-12">
                                <textarea class="form-control form-control-sm" rows="8"
                                          placeholder="Your Message*"></textarea>
            </div>
            <div class="col-12 text-end">
              <button class="btn btn-sm btn-primary">Send Message</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="panel">
        <div class="panel-header">
          <h5>Contact Form Two</h5>
        </div>
        <div class="panel-body">
          <div class="row g-3">
            <div class="col-sm-6">
              <div class="input-group">
                <span class="input-group-text"><i class="fa-solid fa-user"></i></span>
                <input type="text" class="form-control form-control-sm" placeholder="Your Name*">
              </div>
            </div>
            <div class="col-sm-6">
              <div class="input-group">
                <span class="input-group-text"><i class="fa-solid fa-at"></i></span>
                <input type="email" class="form-control form-control-sm" placeholder="Your Email*">
              </div>
            </div>
            <div class="col-sm-6">
              <div class="input-group">
                <span class="input-group-text"><i class="fa-solid fa-phone"></i></span>
                <input type="tel" class="form-control form-control-sm" placeholder="Your Phone*">
              </div>
            </div>
            <div class="col-sm-6">
              <div class="input-group">
                <span class="input-group-text"><i class="fa-solid fa-globe"></i></span>
                <input type="text" class="form-control form-control-sm" placeholder="Your Website*">
              </div>
            </div>
            <div class="col-12">
              <div class="input-group">
                <span class="input-group-text"><i class="fa-solid fa-pen"></i></span>
                <input type="text" class="form-control form-control-sm" placeholder="Subject*">
              </div>
            </div>
            <div class="col-12">
                                <textarea class="form-control form-control-sm" rows="8"
                                          placeholder="Your Message*"></textarea>
            </div>
            <div class="col-12 text-end">
              <button class="btn btn-sm btn-primary">Send Message</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="panel">
        <div class="panel-header">
          <h5>Contact Form Three</h5>
        </div>
        <div class="panel-body">
          <div class="row g-3">
            <div class="col-sm-6">
              <div class="row g-3">
                <div class="col-12">
                  <input type="text" class="form-control form-control-sm"
                         placeholder="Your Name*">
                </div>
                <div class="col-12">
                  <input type="email" class="form-control form-control-sm"
                         placeholder="Your Email*">
                </div>
                <div class="col-12">
                  <input type="tel" class="form-control form-control-sm"
                         placeholder="Your Phone*">
                </div>
                <div class="col-12">
                  <input type="text" class="form-control form-control-sm"
                         placeholder="Your Website*">
                </div>
                <div class="col-12">
                  <input type="text" class="form-control form-control-sm" placeholder="Subject*">
                </div>
              </div>
            </div>
            <div class="col-sm-6">
                                <textarea class="form-control form-control-sm h-100" rows="8"
                                          placeholder="Your Message*"></textarea>
            </div>
            <div class="col-12 text-end">
              <button class="btn btn-sm btn-primary">Send Message</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="panel">
        <div class="panel-header">
          <h5>Contact Form Four</h5>
        </div>
        <div class="panel-body">
          <div class="row g-3">
            <div class="col-sm-6">
              <div class="row g-3">
                <div class="col-12">
                  <div class="input-group">
                    <span class="input-group-text"><i class="fa-solid fa-user"></i></span>
                    <input type="text" class="form-control form-control-sm"
                           placeholder="Your Name*">
                  </div>
                </div>
                <div class="col-12">
                  <div class="input-group">
                    <span class="input-group-text"><i class="fa-solid fa-at"></i></span>
                    <input type="email" class="form-control form-control-sm"
                           placeholder="Your Email*">
                  </div>
                </div>
                <div class="col-12">
                  <div class="input-group">
                    <span class="input-group-text"><i class="fa-solid fa-phone"></i></span>
                    <input type="tel" class="form-control form-control-sm"
                           placeholder="Your Phone*">
                  </div>
                </div>
                <div class="col-12">
                  <div class="input-group">
                    <span class="input-group-text"><i class="fa-solid fa-globe"></i></span>
                    <input type="text" class="form-control form-control-sm"
                           placeholder="Your Website*">
                  </div>
                </div>
                <div class="col-12">
                  <div class="input-group">
                    <span class="input-group-text"><i class="fa-solid fa-pen"></i></span>
                    <input type="text" class="form-control form-control-sm"
                           placeholder="Subject*">
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
                                <textarea class="form-control form-control-sm h-100" rows="8"
                                          placeholder="Your Message*"></textarea>
            </div>
            <div class="col-12 text-end">
              <button class="btn btn-sm btn-primary">Send Message</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>