<script setup>

</script>

<template>
  <div class="email-container">
    <h2 class="page-title">Promotion</h2>
    <table>
      <tbody>
      <tr>
        <td>
          <div class="mail-header">
            <div class="logo">
              <a href="https://html.digiboard.codebasket.xyz/" target="_blank"><img src="@/assets/images/logo-black.png" alt="Logo"></a>
            </div>
          </div>
        </td>
      </tr>
      <tr>
        <td>
          <div class="mail-img-2">
            <img src="@/assets/images/promotion.png" alt="New Arrival">
          </div>
        </td>
      </tr>
      <tr>
        <td>
          <h2 class="mail-title">Introducing our newest arrivals: the perfect blend of fashion and function.</h2>
        </td>
      </tr>
      <tr>
        <td>
          <div class="mail-body">
            <div class="row mb-30">
              <div class="col-6">
                <div class="product-card">
                  <div class="part-img">
                    <a href="#"><img src="@/assets/images/product-img-1.jpg" alt="Product"></a>
                  </div>
                  <div class="part-txt">
                    <span class="product-title"><a href="#">AKG Pro Audio K72 Closed-Back Studio Headphone</a></span>
                    <span class="product-price">$150.00</span>
                  </div>
                </div>
              </div>
              <div class="col-6">
                <div class="product-card">
                  <div class="part-img">
                    <a href="#"><img src="@/assets/images/product-img-2.png" alt="Product"></a>
                  </div>
                  <div class="part-txt">
                    <span class="product-title"><a href="#">AKG Pro Audio K72 Closed-Back Studio Headphone</a></span>
                    <span class="product-price">$150.00</span>
                  </div>
                </div>
              </div>
              <div class="col-6">
                <div class="product-card">
                  <div class="part-img">
                    <a href="#"><img src="@/assets/images/product-img-3.jpg" alt="Product"></a>
                  </div>
                  <div class="part-txt">
                    <span class="product-title"><a href="#">AKG Pro Audio K72 Closed-Back Studio Headphone</a></span>
                    <span class="product-price">$150.00</span>
                  </div>
                </div>
              </div>
              <div class="col-6">
                <div class="product-card">
                  <div class="part-img">
                    <a href="#"><img src="@/assets/images/product-img-4.jpg" alt="Product"></a>
                  </div>
                  <div class="part-txt">
                    <span class="product-title"><a href="#">AKG Pro Audio K72 Closed-Back Studio Headphone</a></span>
                    <span class="product-price">$150.00</span>
                  </div>
                </div>
              </div>
            </div>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus sapiente adipisci at voluptate, possimus, voluptatum molestias magni aut corrupti illum neque commodi dolores ducimus quam odit doloribus nesciunt eos architecto.</p>
            <p>Need help? Visit our <a href="#">forum</a></p>
          </div>
        </td>
      </tr>
      <tr>
        <td>
          <div class="mail-footer">
            <div class="logo"><img src="@/assets/images/logo-big.png" alt="LOGO"></div>
            <div class="footer-social">
              <a href="#" title="Facebook" target="_blank"><img src="@/assets/images/facebook.png" alt="facebook"></a>
              <a href="#" title="Instagram" target="_blank"><img src="@/assets/images/instagram.png" alt="instagram"></a>
              <a href="#" title="Twitter" target="_blank"><img src="@/assets/images/twitter.png" alt="twitter"></a>
              <a href="#" title="Linkedin" target="_blank"><img src="@/assets/images/linkedin.png" alt="linkedin"></a>
            </div>
          </div>
        </td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<style scoped>

</style>