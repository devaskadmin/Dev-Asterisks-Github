<script setup>

</script>

<template>
  <div class="col-xxl-4 col-md-6">
    <div class="panel">
      <div class="panel-header">
        <h5>Social Media Visitor</h5>
        <div class="btn-box d-sm-block d-none">
          <button class="btn btn-sm btn-outline-primary">Week</button>
          <button class="btn btn-sm btn-outline-primary">Month</button>
          <button class="btn btn-sm btn-outline-primary">Year</button>
        </div>
      </div>
      <div class="panel-body">
        <table class="table table-borderless visitor-table">
          <thead>
          <tr>
            <th>Sources</th>
            <th>Visitor</th>
          </tr>
          </thead>
          <tbody>
          <tr>
            <td><span class="text-fb"><i class="fa-brands fa-facebook-f"></i></span> Facebook</td>
            <td>153,100</td>
          </tr>
          <tr>
            <td><span class="text-behance"><i class="fa-brands fa-behance"></i></span> Behance</td>
            <td>234,200</td>
          </tr>
          <tr>
            <td><span class="text-comb"><i class="fa-brands fa-y-combinator"></i></span> Combinator</td>
            <td>326,012</td>
          </tr>
          <tr>
            <td><span class="text-insta"><i class="fa-brands fa-instagram"></i></span> Instagram</td>
            <td>124,420</td>
          </tr>
          <tr>
            <td><span class="text-dribble"><i class="fa-brands fa-dribbble"></i></span> Dribble</td>
            <td>554,220</td>
          </tr>
          <tr>
            <td><span class="text-pinterest"><i class="fa-brands fa-pinterest-p"></i></span> Pinterest</td>
            <td>134,800</td>
          </tr>
          <tr>
            <td><span class="text-linkedin"><i class="fa-brands fa-linkedin-in"></i></span> Linkedin</td>
            <td>254,812</td>
          </tr>
          <tr>
            <td><span class="text-twitter"><i class="fa-brands fa-twitter"></i></span> Twitter</td>
            <td>124,250</td>
          </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>