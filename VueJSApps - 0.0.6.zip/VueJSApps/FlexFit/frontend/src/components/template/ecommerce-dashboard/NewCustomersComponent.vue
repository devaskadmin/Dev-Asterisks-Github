<script setup>

</script>

<template>
  <div class="col-xxl-4 col-md-6">
    <div class="panel">
      <div class="panel-header">
        <h5>New Customers</h5>
      </div>
      <div class="panel-body">
        <table class="table table-borderless new-customer-table">
          <tbody>
          <tr>
            <td>
              <div class="new-customer">
                <div class="part-img">
                  <img src="@/assets/images/avatar.png" alt="Image">
                </div>
                <div class="part-txt">
                  <p class="customer-name">Iftikar Ammed</p>
                  <span>@iftikarahmed</span>
                </div>
              </div>
            </td>
            <td>2 Orders</td>
            <td>$179</td>
          </tr>
          <tr>
            <td>
              <div class="new-customer">
                <div class="part-img">
                  <img src="@/assets/images/avatar-2.png" alt="Image">
                </div>
                <div class="part-txt">
                  <p class="customer-name">Sadab Khan</p>
                  <span>@sadabkhan</span>
                </div>
              </div>
            </td>
            <td>2 Orders</td>
            <td>$179</td>
          </tr>
          <tr>
            <td>
              <div class="new-customer">
                <div class="part-img">
                  <img src="@/assets/images/avatar-3.png" alt="Image">
                </div>
                <div class="part-txt">
                  <p class="customer-name">Hoyder Ali</p>
                  <span>@hoyderali</span>
                </div>
              </div>
            </td>
            <td>2 Orders</td>
            <td>$179</td>
          </tr>
          <tr>
            <td>
              <div class="new-customer">
                <div class="part-img">
                  <img src="@/assets/images/avatar-4.png" alt="Image">
                </div>
                <div class="part-txt">
                  <p class="customer-name">Hardik Ali</p>
                  <span>@hardikali</span>
                </div>
              </div>
            </td>
            <td>2 Orders</td>
            <td>$179</td>
          </tr>
          <tr>
            <td>
              <div class="new-customer">
                <div class="part-img">
                  <img src="@/assets/images/avatar-5.png" alt="Image">
                </div>
                <div class="part-txt">
                  <p class="customer-name">Alaysa Haly</p>
                  <span>@alaysahaly</span>
                </div>
              </div>
            </td>
            <td>2 Orders</td>
            <td>$179</td>
          </tr>
          <tr>
            <td>
              <div class="new-customer">
                <div class="part-img">
                  <img src="@/assets/images/avatar-6.png" alt="Image">
                </div>
                <div class="part-txt">
                  <p class="customer-name">Natalush Khan</p>
                  <span>@natalushkhan</span>
                </div>
              </div>
            </td>
            <td>2 Orders</td>
            <td>$179</td>
          </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>