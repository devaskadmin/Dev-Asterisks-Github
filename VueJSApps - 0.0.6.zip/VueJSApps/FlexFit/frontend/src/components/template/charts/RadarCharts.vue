<script setup>

</script>

<template>
  <div class="col-lg-6">
    <div class="panel">
      <div class="panel-header">
        <h5>Radar Charts</h5>
      </div>
      <div class="panel-body pb-0">
        <slot/>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>