<script setup>

</script>

<template>
  <div class="col-lg-6">
    <div class="panel chart-panel-1">
      <div class="panel-header">
        <h5>Candlestick Charts</h5>
      </div>
      <div class="panel-body">
        <div>
          <slot/>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>