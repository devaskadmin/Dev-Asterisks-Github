<script setup>

</script>

<template>
  <div class="col-lg-6">
    <div class="panel">
      <div class="panel-header">
        <h5>Pending Works</h5>
      </div>
      <div class="panel-body p-0">
        <table class="table table-hover pending-task-table" tabindex="1">
          <tr>
            <td>
              <div class="task-box">
                <span>Database tools</span>
                <span>Jul 25, 2017 for Alimul Alrazy</span>
              </div>
            </td>
            <td>
                                    <span class="d-block text-end">
                                        <span class="badge bg-primary px-2">Processing</span>
                                    </span>
            </td>
          </tr>
          <tr>
            <td>
              <div class="task-box">
                <span>Technologycal tools</span>
                <span>Jul 25, 2017 for Alimul Alrazy</span>
              </div>
            </td>
            <td>
                                    <span class="d-block text-end">
                                        <span class="badge bg-success px-2">Completed</span>
                                    </span>
            </td>
          </tr>
          <tr>
            <td>
              <div class="task-box">
                <span>Transaction</span>
                <span>Jul 25, 2017 for Alimul Alrazy</span>
              </div>
            </td>
            <td>
                                    <span class="d-block text-end">
                                        <span class="badge bg-danger px-2">On hold</span>
                                    </span>
            </td>
          </tr>
          <tr>
            <td>
              <div class="task-box">
                <span>Training tools</span>
                <span>Jul 25, 2017 for Alimul Alrazy</span>
              </div>
            </td>
            <td>
                                    <span class="d-block text-end">
                                        <span class="badge bg-primary px-2">Processing</span>
                                    </span>
            </td>
          </tr>
          <tr>
            <td>
              <div class="task-box">
                <span>Private chat module</span>
                <span>Jul 25, 2017 for Alimul Alrazy</span>
              </div>
            </td>
            <td>
                                    <span class="d-block text-end">
                                        <span class="badge bg-success px-2">Completed</span>
                                    </span>
            </td>
          </tr>
          <tr>
            <td>
              <div class="task-box">
                <span>Appointment booking with</span>
                <span>Jul 25, 2017 for Alimul Alrazy</span>
              </div>
            </td>
            <td>
                                    <span class="d-block text-end">
                                        <span class="badge bg-primary px-2">Processing</span>
                                    </span>
            </td>
          </tr>
        </table>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>