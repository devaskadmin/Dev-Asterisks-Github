<script setup>

</script>

<template>
  <div class="avatar-box">
    <div class="avatar avatar-sm">
      <img src="@/assets/images/avatar-2.png" alt="image">
    </div>
    <div class="avatar avatar-sm">
      <img src="@/assets/images/avatar-3.png" alt="image">
    </div>
    <div class="avatar avatar-sm">
      <img src="@/assets/images/avatar-4.png" alt="image">
    </div>
    <div class="avatar avatar-sm bg-primary rounded-circle d-flex justify-content-center align-items-center text-white">6</div>
  </div>
</template>

<style scoped>

</style>