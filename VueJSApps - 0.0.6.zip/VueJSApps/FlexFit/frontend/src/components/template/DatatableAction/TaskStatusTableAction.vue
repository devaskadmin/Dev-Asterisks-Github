<script setup>

</script>

<template>
  <select class="form-control form-control-sm form-select">
    <option value="not-started">Not Started</option>
    <option value="pending">Pending</option>
    <option value="on-hold">On Hold</option>
    <option value="in-progress">In Progress</option>
    <option value="completed">Completed</option>
  </select>
</template>

<style scoped>

</style>