<script setup>

</script>

<template>
  <select class="form-control form-control-sm form-select">
    <option value="low">Low</option>
    <option value="medium">Medium</option>
    <option value="high">High</option>
    <option value="urgent">Urgent</option>
  </select>
</template>

<style scoped>

</style>