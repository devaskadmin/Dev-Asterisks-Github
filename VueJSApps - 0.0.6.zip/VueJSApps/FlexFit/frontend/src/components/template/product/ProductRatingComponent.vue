<script setup>

</script>

<template>
  <div class="rating">
    <div class="star">
        <i class="fa-solid fa-star starred"></i>
        <i class="fa-solid fa-star starred"></i>
        <i class="fa-solid fa-star starred"></i>
        <i class="fa-solid fa-star starred"></i>
        <i class="fa-solid fa-star"></i>
    </div>
    <div class="rating-amount">(42)</div>
    </div>
</template>

<style scoped>

</style>