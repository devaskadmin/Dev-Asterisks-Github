<script setup>

</script>

<template>
  <div class="col-xxl-4 col-md-6">
    <div class="panel">
      <div class="panel-header">
        <h5>Recent Activity</h5>
        <div class="btn-box">
          <a href="#" class="btn btn-sm btn-primary">View All</a>
        </div>
      </div>
      <div class="panel-body">
        <ul class="hr-recent-activity">
          <li>
            <div class="left">
              <span class="activity-name">Leave Approval Request</span>
              <span class="activity-short">From "RuthDyer" UiDesign Leave On Monday 12 Jan 2020.</span>
            </div>
            <div class="right">
              <span class="activity-time">6 min ago</span>
            </div>
          </li>
          <li>
            <div class="left">
              <span class="activity-name">Work Update</span>
              <span class="activity-short">From "RuthDyer" UiDesign Leave On Monday 12 Jan 2020.</span>
            </div>
            <div class="right">
              <span class="activity-time">16 min ago</span>
            </div>
          </li>
          <li>
            <div class="left">
              <span class="activity-name">Leave Approval Request</span>
              <span class="activity-short">From "RuthDyer" UiDesign Leave On Monday 12 Jan 2020.</span>
            </div>
            <div class="right">
              <span class="activity-time">6 min ago</span>
            </div>
          </li>
          <li>
            <div class="left">
              <span class="activity-name">Work Update</span>
              <span class="activity-short">From "RuthDyer" UiDesign Leave On Monday 12 Jan 2020.</span>
            </div>
            <div class="right">
              <span class="activity-time">16 min ago</span>
            </div>
          </li>
          <li>
            <div class="left">
              <span class="activity-name">Leave Approval Request</span>
              <span class="activity-short">From "RuthDyer" UiDesign Leave On Monday 12 Jan 2020.</span>
            </div>
            <div class="right">
              <span class="activity-time">6 min ago</span>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>