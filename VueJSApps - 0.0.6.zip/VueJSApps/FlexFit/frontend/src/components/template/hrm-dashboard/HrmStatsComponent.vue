<script setup>

</script>

<template>
  <div class="row mb-25">
    <div class="col-lg-3 col-6 col-xs-12">
      <div class="dashboard-top-box dashboard-top-box-2 rounded border-0 panel-bg">
        <div class="left">
          <p class="d-flex justify-content-between mb-2">Total Employees</p>
          <h3 class="fw-normal">134,152</h3>
          <p class="text-muted"><small>124 for last month</small></p>
        </div>
        <div class="right">
          <div class="part-icon text-light rounded">
            <span><i class="fa-light fa-user-plus"></i></span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-6 col-xs-12">
      <div class="dashboard-top-box dashboard-top-box-2 rounded border-0 panel-bg">
        <div class="left">
          <p class="d-flex justify-content-between mb-2">Campaign Sent</p>
          <h3 class="fw-normal">12,412</h3>
          <p class="text-muted"><small>4 for last month</small></p>
        </div>
        <div class="right">
          <div class="part-icon text-light rounded">
            <span><i class="fa-light fa-bullhorn"></i></span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-6 col-xs-12">
      <div class="dashboard-top-box dashboard-top-box-2 rounded border-0 panel-bg">
        <div class="left">
          <p class="d-flex justify-content-between mb-2">Annual Profit</p>
          <h3 class="fw-normal">$134,152</h3>
          <p class="text-muted"><small>124 for last month</small></p>
        </div>
        <div class="right">
          <div class="part-icon text-light rounded">
            <span><i class="fa-light fa-dollar-sign"></i></span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-6 col-xs-12">
      <div class="dashboard-top-box dashboard-top-box-2 rounded border-0 panel-bg">
        <div class="left">
          <p class="d-flex justify-content-between mb-2">Lead Conversation</p>
          <h3 class="fw-normal">52%</h3>
          <p class="text-muted"><small>124 for last month</small></p>
        </div>
        <div class="right">
          <div class="part-icon text-light rounded">
            <span><i class="fa-light fa-magnifying-glass-chart"></i></span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>