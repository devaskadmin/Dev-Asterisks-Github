<script setup>

</script>

<template>
  <div class="col-xxl-3 col-md-6">
    <div class="panel">
      <div class="panel-header">
        <h5>Notice Board</h5>
      </div>
      <div class="panel-body">
        <ul class="hr-notice-board">
          <li>
            <div class="activity-box">
              <div class="date-box date-box-lg">
                <span>14</span>
                <span>Feb</span>
              </div>
              <div class="part-txt">
                <span>Meeting for campaign with sales team</span>
                <span class="text-muted">12:00am - 03:30pm</span>
              </div>
            </div>
          </li>
          <li>
            <div class="activity-box">
              <div class="date-box date-box-lg">
                <span>14</span>
                <span>Feb</span>
              </div>
              <div class="part-txt">
                <span>Meeting for campaign with sales team</span>
                <span class="text-muted">12:00am - 03:30pm</span>
              </div>
            </div>
          </li>
          <li>
            <div class="activity-box">
              <div class="date-box date-box-lg">
                <span>14</span>
                <span>Feb</span>
              </div>
              <div class="part-txt">
                <span>Meeting for campaign with sales team</span>
                <span class="text-muted">12:00am - 03:30pm</span>
              </div>
            </div>
          </li>
          <li>
            <div class="activity-box">
              <div class="date-box date-box-lg">
                <span>14</span>
                <span>Feb</span>
              </div>
              <div class="part-txt">
                <span>Meeting for campaign with sales team</span>
                <span class="text-muted">12:00am - 03:30pm</span>
              </div>
            </div>
          </li>
          <li>
            <div class="activity-box">
              <div class="date-box date-box-lg">
                <span>14</span>
                <span>Feb</span>
              </div>
              <div class="part-txt">
                <span>Meeting for campaign with sales team</span>
                <span class="text-muted">12:00am - 03:30pm</span>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>