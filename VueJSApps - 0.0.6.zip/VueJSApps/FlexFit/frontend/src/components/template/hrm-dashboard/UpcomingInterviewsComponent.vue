<script setup>

</script>

<template>
  <div class="col-xxl-3 col-md-4">
    <div class="panel">
      <div class="panel-header">
        <h5>Upcoming Interviews</h5>
        <div class="btn-box">
          <a href="#" class="btn btn-sm btn-outline-primary">View All</a>
        </div>
      </div>
      <div class="panel-body">
        <ul class="upcoming-interview">
          <li>
            <div class="avatar avatar-lg">
              <img src="@/assets/images/avatar-2.png" class="rounded" alt="user">
            </div>
            <div class="part-txt">
              <span class="applicant-name">Natalie Gibson</span>
              <span class="applicant-role">
                    <small><span class="text-muted">Ui/UX Designer</span></small>
                </span>
            </div>
          </li>
          <li>
            <div class="avatar avatar-lg">
              <img src="@/assets/images/avatar-3.png" class="rounded" alt="user">
            </div>
            <div class="part-txt">
              <span class="applicant-name">Natalie Gibson</span>
              <span class="applicant-role">
                    <small><span class="text-muted">Ui/UX Designer</span></small>
                </span>
            </div>
          </li>
          <li>
            <div class="avatar avatar-lg">
              <img src="@/assets/images/avatar-4.png" class="rounded" alt="user">
            </div>
            <div class="part-txt">
              <span class="applicant-name">Natalie Gibson</span>
              <span class="applicant-role">
                    <small><span class="text-muted">Ui/UX Designer</span></small>
                </span>
            </div>
          </li>
          <li>
            <div class="avatar avatar-lg">
              <img src="@/assets/images/avatar-5.png" class="rounded" alt="user">
            </div>
            <div class="part-txt">
              <span class="applicant-name">Natalie Gibson</span>
              <span class="applicant-role">
                    <small><span class="text-muted">Ui/UX Designer</span></small>
                </span>
            </div>
          </li>
          <li>
            <div class="avatar avatar-lg">
              <img src="@/assets/images/avatar-6.png" class="rounded" alt="user">
            </div>
            <div class="part-txt">
              <span class="applicant-name">Natalie Gibson</span>
              <span class="applicant-role">
                    <small><span class="text-muted">Ui/UX Designer</span></small>
                </span>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>