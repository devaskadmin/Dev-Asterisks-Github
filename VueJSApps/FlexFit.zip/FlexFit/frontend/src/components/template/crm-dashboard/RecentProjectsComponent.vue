<script setup>

</script>

<template>
  <div class="col-lg-4">
    <div class="panel">
      <div class="panel-header">
        <h5>Recent Projects</h5>
        <div class="btn-box">
          <a href="#" class="btn btn-sm btn-outline-primary">View All</a>
        </div>
      </div>
      <div class="panel-body">
        <div class="table-responsive">
          <table class="table table-striped mb-0 recent-project-table">
            <thead>
            <tr>
              <th>Project Name</th>
              <th>Progress</th>
              <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td>
                <span>Office Management</span>
                <span class="d-block">9 tasks completed</span>
              </td>
              <td>
                <div class="progress" role="progressbar" aria-label="Basic example" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100">
                  <div class="progress-bar" style="width: 85%"></div>
                </div>
              </td>
              <td>
                <div class="btn-box d-flex justify-content-end gap-3">
                  <button class="btn-flush"><i class="fa-light fa-eye"></i></button>
                  <button class="btn-flush"><i class="fa-light fa-pen"></i></button>
                  <button class="btn-flush"><i class="fa-light fa-trash"></i></button>
                </div>
              </td>
            </tr>
            <tr>
              <td>
                <span>Office Management</span>
                <span class="d-block">9 tasks completed</span>
              </td>
              <td>
                <div class="progress" role="progressbar" aria-label="Basic example" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100">
                  <div class="progress-bar" style="width: 85%"></div>
                </div>
              </td>
              <td>
                <div class="btn-box d-flex justify-content-end gap-3">
                  <button class="btn-flush"><i class="fa-light fa-eye"></i></button>
                  <button class="btn-flush"><i class="fa-light fa-pen"></i></button>
                  <button class="btn-flush"><i class="fa-light fa-trash"></i></button>
                </div>
              </td>
            </tr>
            <tr>
              <td>
                <span>Office Management</span>
                <span class="d-block">9 tasks completed</span>
              </td>
              <td>
                <div class="progress" role="progressbar" aria-label="Basic example" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100">
                  <div class="progress-bar" style="width: 85%"></div>
                </div>
              </td>
              <td>
                <div class="btn-box d-flex justify-content-end gap-3">
                  <button class="btn-flush"><i class="fa-light fa-eye"></i></button>
                  <button class="btn-flush"><i class="fa-light fa-pen"></i></button>
                  <button class="btn-flush"><i class="fa-light fa-trash"></i></button>
                </div>
              </td>
            </tr>
            <tr>
              <td>
                <span>Office Management</span>
                <span class="d-block">9 tasks completed</span>
              </td>
              <td>
                <div class="progress" role="progressbar" aria-label="Basic example" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100">
                  <div class="progress-bar" style="width: 85%"></div>
                </div>
              </td>
              <td>
                <div class="btn-box d-flex justify-content-end gap-3">
                  <button class="btn-flush"><i class="fa-light fa-eye"></i></button>
                  <button class="btn-flush"><i class="fa-light fa-pen"></i></button>
                  <button class="btn-flush"><i class="fa-light fa-trash"></i></button>
                </div>
              </td>
            </tr>
            <tr>
              <td>
                <span>Office Management</span>
                <span class="d-block">9 tasks completed</span>
              </td>
              <td>
                <div class="progress" role="progressbar" aria-label="Basic example" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100">
                  <div class="progress-bar" style="width: 85%"></div>
                </div>
              </td>
              <td>
                <div class="btn-box d-flex justify-content-end gap-3">
                  <button class="btn-flush"><i class="fa-light fa-eye"></i></button>
                  <button class="btn-flush"><i class="fa-light fa-pen"></i></button>
                  <button class="btn-flush"><i class="fa-light fa-trash"></i></button>
                </div>
              </td>
            </tr>
            <tr>
              <td>
                <span>Office Management</span>
                <span class="d-block">9 tasks completed</span>
              </td>
              <td>
                <div class="progress" role="progressbar" aria-label="Basic example" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100">
                  <div class="progress-bar" style="width: 85%"></div>
                </div>
              </td>
              <td>
                <div class="btn-box d-flex justify-content-end gap-3">
                  <button class="btn-flush"><i class="fa-light fa-eye"></i></button>
                  <button class="btn-flush"><i class="fa-light fa-pen"></i></button>
                  <button class="btn-flush"><i class="fa-light fa-trash"></i></button>
                </div>
              </td>
            </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>