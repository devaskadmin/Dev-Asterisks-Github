<script setup>

</script>

<template>
  <div class="btn-box ms-0">
    <button class="btn-flush"><i class="fa-light fa-box-archive"></i></button>
    <button class="btn-flush"><i class="fa-light fa-circle-exclamation"></i></button>
    <button class="btn-flush"><i class="fa-light fa-envelope"></i></button>
    <button class="btn-flush"><i class="fa-light fa-trash-can"></i></button>
  </div>
</template>

<style scoped>

</style>