<script setup>

</script>

<template>
  <div class="btn-box">
    <button class="btn btn-sm btn-icon btn-primary" data-bs-toggle="modal" data-bs-target="#editTaskModal"><i class="fa-light fa-edit"></i></button>
    <button class="btn btn-sm btn-icon btn-danger"><i class="fa-light fa-trash-can"></i></button>
  </div>
</template>

<style scoped>

</style>