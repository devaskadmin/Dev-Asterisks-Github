<script setup>

</script>

<template>
  <div class="digi-dropdown dropdown d-inline-block">
    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="dropdown" aria-expanded="false">Action <i class="fa-regular fa-angle-down"></i></button>
    <ul class="digi-dropdown-menu dropdown-menu dropdown-slim dropdown-menu-sm">
        <li><a href="#" class="dropdown-item"><span class="dropdown-icon"><i class="fa-light fa-eye"></i></span> View</a></li>
        <li><a href="#" class="dropdown-item"><span class="dropdown-icon"><i class="fa-light fa-pen-to-square"></i></span> Edit</a></li>
        <li><a href="#" class="dropdown-item"><span class="dropdown-icon"><i class="fa-light fa-id-card"></i></span> ID Card</a></li>
        <li><a href="#" class="dropdown-item"><span class="dropdown-icon"><i class="fa-light fa-pen-nib"></i></span> Resign</a></li>
        <li><a href="#" class="dropdown-item"><span class="dropdown-icon"><i class="fa-light fa-arrow-right-from-bracket"></i></span> Left</a></li>
        <li><a href="#" class="dropdown-item"><span class="dropdown-icon"><i class="fa-light fa-trash-can"></i></span> Delete</a></li>
    </ul>
  </div>
</template>

<style scoped>

</style>