<script setup>

</script>

<template>
  <div class="btn-box">
    <button><i class="fa-light fa-eye"></i></button>
    <button><i class="fa-light fa-pen"></i></button>
    <button><i class="fa-light fa-trash"></i></button>
  </div>
</template>

<style scoped>

</style>