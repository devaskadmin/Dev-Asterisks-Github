<script setup>

</script>

<template>
  <div class="col-lg-6">
    <div class="panel">
      <div class="panel-header">
        <h5>Polar Area Charts</h5>
      </div>
      <div class="panel-body">
        <slot/>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>