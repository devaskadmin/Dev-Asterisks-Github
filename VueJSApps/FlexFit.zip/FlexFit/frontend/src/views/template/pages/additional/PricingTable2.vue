<script setup>

</script>

<template>
  <div class="panel pricing-panel-2">
    <div class="panel-body d-flex justify-content-center align-items-center">
      <div class="pricing w-100">
        <div class="container">
          <div class="row">
            <div class="col-lg-4 col-sm-6">
              <div class="pricing-table">
                <div class="top">
                  <p>Primary</p>
                  <h3>$120</h3>
                  <span>Monthly</span>
                </div>
                <div class="middle">
                  <ul>
                    <li>Unlimited Members</li>
                    <li>Unlimited Projects</li>
                    <li>Client Login</li>
                    <li>Unlimited Storage</li>
                    <li>24/7 Support</li>
                  </ul>
                </div>
                <div class="bottom">
                  <a href="#" class="btn btn-success px-4 py-2 rounded-pill">Start Now</a>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-sm-6">
              <div class="pricing-table">
                <div class="top">
                  <p>Primary</p>
                  <h3>$120</h3>
                  <span>Monthly</span>
                </div>
                <div class="middle">
                  <ul>
                    <li>Unlimited Members</li>
                    <li>Unlimited Projects</li>
                    <li>Client Login</li>
                    <li>Unlimited Storage</li>
                    <li>24/7 Support</li>
                  </ul>
                </div>
                <div class="bottom">
                  <a href="#" class="btn btn-success px-4 py-2 rounded-pill">Start Now</a>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-sm-6">
              <div class="pricing-table">
                <div class="top">
                  <p>Primary</p>
                  <h3>$120</h3>
                  <span>Monthly</span>
                </div>
                <div class="middle">
                  <ul>
                    <li>Unlimited Members</li>
                    <li>Unlimited Projects</li>
                    <li>Client Login</li>
                    <li>Unlimited Storage</li>
                    <li>24/7 Support</li>
                  </ul>
                </div>
                <div class="bottom">
                  <a href="#" class="btn btn-success px-4 py-2 rounded-pill">Start Now</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>