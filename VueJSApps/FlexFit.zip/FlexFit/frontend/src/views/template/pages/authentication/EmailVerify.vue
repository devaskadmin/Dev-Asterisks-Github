<script setup>

</script>

<template>
  <div class="static-body">
    <div class="panel bg-transparent">
      <div class="panel-body">
        <div class="logo text-center">
          <img src="@/assets/images/logo-small.png" alt="logo">
        </div>
        <div class="part-txt text-center">
          <h2>Verify your email</h2>
          <p>Did’t receive an email? <a href="#">Try Again</a></p>
          <router-link to="/" class="btn btn-primary px-3">Click To Verify</router-link>
        </div>
        <div class="part-img w-75 m-auto">
          <img src="@/assets/images/verify-email.png" alt="image">
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>