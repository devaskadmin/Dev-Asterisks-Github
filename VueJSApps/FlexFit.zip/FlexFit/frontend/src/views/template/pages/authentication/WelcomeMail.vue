<script setup>

</script>

<template>
  <div class="email-container">
    <h2 class="page-title">Welcome</h2>
    <table>
      <tbody>
      <tr>
        <td>
          <div class="mail-header">
            <div class="logo">
              <a href="https://html.digiboard.codebasket.xyz/" target="_blank"><img src="@/assets/images/logo-black.png" alt="Logo"></a>
            </div>
          </div>
        </td>
      </tr>
      <tr>
        <td>
          <div class="mail-img-2">
            <img src="@/assets/images/welcome.png" alt="Welcome">
          </div>
        </td>
      </tr>
      <tr>
        <td>
          <h2 class="mail-title">Welcome To Digiboard</h2>
        </td>
      </tr>
      <tr>
        <td>
          <div class="mail-body">
            <p>We created a personal account for you. Please confirm your email address and use our service to the maximum.</p>
            <a href="#" class="mail-primary-button mb-30" target="_blank">Confirm Email</a>
            <p>Need help? Visit our <a href="#">forum</a></p>
          </div>
        </td>
      </tr>
      <tr>
        <td>
          <div class="mail-footer">
            <div class="logo"><img src="@/assets/images/logo-big.png" alt="LOGO"></div>
            <div class="footer-social">
              <a href="#" title="Facebook" target="_blank"><img src="@/assets/images/facebook.png" alt="facebook"></a>
              <a href="#" title="Instagram" target="_blank"><img src="@/assets/images/instagram.png" alt="instagram"></a>
              <a href="#" title="Twitter" target="_blank"><img src="@/assets/images/twitter.png" alt="twitter"></a>
              <a href="#" title="Linkedin" target="_blank"><img src="@/assets/images/linkedin.png" alt="linkedin"></a>
            </div>
          </div>
        </td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<style scoped>

</style>