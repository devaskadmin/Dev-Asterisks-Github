<script setup>

</script>

<template>
  <div class="email-container">
    <h2 class="page-title">Subscription Confirm</h2>
    <table>
      <tbody>
      <tr>
        <td>
          <div class="mail-header">
            <div class="logo">
              <a href="https://html.digiboard.codebasket.xyz/" target="_blank"><img src="@/assets/images/logo-black.png" alt="Logo"></a>
            </div>
          </div>
        </td>
      </tr>
      <tr>
        <td>
          <div class="mail-img">
            <img src="@/assets/images/confirm.png" alt="Success">
          </div>
        </td>
      </tr>
      <tr>
        <td>
          <h2 class="mail-title">Subscription Success, Here We Go!</h2>
        </td>
      </tr>
      <tr>
        <td>
          <div class="mail-body">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus sapiente adipisci at voluptate, possimus, voluptatum molestias magni aut corrupti illum neque commodi dolores ducimus quam odit doloribus nesciunt eos architecto.</p>
            <p>Need help? Visit our <a href="#">forum</a></p>
          </div>
        </td>
      </tr>
      <tr>
        <td>
          <div class="mail-footer">
            <div class="logo"><img src="@/assets/images/logo-big.png" alt="LOGO"></div>
            <div class="footer-social">
              <a href="#" title="Facebook" target="_blank"><img src="@/assets/images/facebook.png" alt="facebook"></a>
              <a href="#" title="Instagram" target="_blank"><img src="@/assets/images/instagram.png" alt="instagram"></a>
              <a href="#" title="Twitter" target="_blank"><img src="@/assets/images/twitter.png" alt="twitter"></a>
              <a href="#" title="Linkedin" target="_blank"><img src="@/assets/images/linkedin.png" alt="linkedin"></a>
            </div>
          </div>
        </td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<style scoped>

</style>