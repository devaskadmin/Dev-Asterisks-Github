<script setup>

</script>

<template>
  <div class="static-body">
    <div class="panel bg-transparent">
      <div class="panel-body">
        <div class="logo text-center">
          <img src="@/assets/images/logo-small.png" alt="logo">
        </div>
        <div class="part-txt text-center">
          <h2>Your account is deactivated</h2>
          <p>A great name is like a great story. It's one that people want to hear again and again.</p>
          <router-link to="/" class="btn btn-primary px-3">Go To Home Page</router-link>
        </div>
        <div class="part-img w-50 m-auto">
          <img src="@/assets/images/deactivated-img.png" alt="image">
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>