<script setup>

</script>

<template>
  <div class="email-container">
    <h2 class="page-title">Reset Password</h2>
    <table>
      <tbody>
      <tr>
        <td>
          <div class="mail-header">
            <div class="logo">
              <a href="https://html.digiboard.codebasket.xyz/" target="_blank">
                <img src="@/assets/images/logo-black.png" alt="Logo">
              </a>
            </div>
          </div>
        </td>
      </tr>
      <tr>
        <td>
          <div class="mail-img">
            <img src="@/assets/images/reset-password.png" alt="Reset Password">
          </div>
        </td>
      </tr>
      <tr>
        <td>
          <h2 class="mail-title">Reset Your Password</h2>
        </td>
      </tr>
      <tr>
        <td>
          <div class="mail-body">
            <p>Not to worry, we got you! Let's get you a new Password</p>
            <a href="#" class="mail-primary-button mb-30" target="_blank">Reset Password</a>
            <p>Need help? Visit our <a href="#">forum</a></p>
          </div>
        </td>
      </tr>
      <tr>
        <td>
          <div class="mail-footer">
            <div class="logo"><img src="@/assets/images/logo-big.png" alt="LOGO"></div>
            <div class="footer-social">
              <a href="#" title="Facebook" target="_blank"><img src="@/assets/images/facebook.png" alt="facebook"></a>
              <a href="#" title="Instagram" target="_blank"><img src="@/assets/images/instagram.png" alt="instagram"></a>
              <a href="#" title="Twitter" target="_blank"><img src="@/assets/images/twitter.png" alt="twitter"></a>
              <a href="#" title="Linkedin" target="_blank"><img src="@/assets/images/linkedin.png" alt="linkedin"></a>
            </div>
          </div>
        </td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<style scoped>

</style>